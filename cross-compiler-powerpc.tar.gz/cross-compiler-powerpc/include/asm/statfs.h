#ifndef _ASM_POWERPC_STATFS_H
#define _ASM_POWERPC_STATFS_H

#include <asm-generic/statfs.h>

#endif
